package com.example.number_trivialast

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
